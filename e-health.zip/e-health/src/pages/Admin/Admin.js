import Patients from "./Patients";

function Admin() {
  return <Patients />;
}

export default Admin;
